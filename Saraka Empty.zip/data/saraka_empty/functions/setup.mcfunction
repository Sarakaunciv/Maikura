fill -2 63 -2 2 63 2 grass_block
fill -2 61 -2 2 62 2 dirt
fill -2 60 -2 2 60 2 bedrock
setblock 2 64 2 oak_sapling
tp @s 0 64 0
give @s chest{BlockEntityTag:{Items:[{Slot:0,id:bone_meal,Count:64}]}}
setworldspawn 0 64 0