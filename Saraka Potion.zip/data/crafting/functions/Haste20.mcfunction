clear @s knowledge_book 1

give @s potion{CustomPotionColor:16776960,CustomPotionEffects:[{Id:3,Duration:12000,Amplifier:20}]}