execute if entity @s[y_rotation=45..135] run tp @s ~ ~ ~ 90 ~
execute if entity @s[y_rotation=135..-135] run tp @s ~ ~ ~ 180 ~
execute if entity @s[y_rotation=-135..-45] run tp @s ~ ~ ~ -90 ~
execute if entity @s[y_rotation=-45..45] run tp @s ~ ~ ~ 0 ~

execute if entity @s[x_rotation=-90..-30] run tp @s ~ ~ ~ ~ -90
execute if entity @s[x_rotation=-30..30] run tp @s ~ ~ ~ ~ 0
execute if entity @s[x_rotation=30..90] run tp @s ~ ~ ~ ~ 90
