clear @s knowledge_book 1

fill ~-15 ~-1 ~-15 ~15 ~6 ~15 minecraft:command_block{auto: 1b, Command: 'fill ~ ~-1 ~ ~ ~ ~ air destroy', id: "minecraft:command_block"} replace minecraft:dispenser{CustomName:'{"text":"Destroy y-1"}'}
fill ~-15 ~-1 ~-15 ~15 ~6 ~15 minecraft:command_block{auto: 1b, Command: 'fill ~-2 ~-1 ~-2 ~2 ~3 ~2 air destroy', id: "minecraft:command_block"} replace minecraft:dispenser{CustomName:'{"text":"Destroy y-1 5x5"}'}
fill ~-15 ~-1 ~-15 ~15 ~6 ~15 minecraft:command_block{auto: 1b, Command: 'fill ~-7 ~-1 ~-7 ~7 ~13 ~7 air destroy', id: "minecraft:command_block"} replace minecraft:dispenser{CustomName:'{"text":"Destroy y-1 15x15"}'}
fill ~-15 ~-1 ~-15 ~15 ~6 ~15 minecraft:command_block{auto: 1b, Command: 'fill ~-15 ~-1 ~-15 ~15 ~29 ~15 air destroy', id: "minecraft:command_block"} replace minecraft:dispenser{CustomName:'{"text":"Destroy y-1 31x31"}'}

advancement revoke @s only saraka_potion:0_update_31
recipe take @s saraka_potion:0_update_31