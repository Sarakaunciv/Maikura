clear @s knowledge_book 1

give @s splash_potion{CustomPotionColor:6579300,CustomPotionEffects:[{Id:31,Duration:3000,Amplifier:9}]}

advancement revoke @s only saraka_potion:bado10
recipe take @s saraka_potion:bado10