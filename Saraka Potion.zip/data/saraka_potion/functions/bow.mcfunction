clear @s knowledge_book 1

give @s bow{Enchantments:[{lvl:20,id:power},{lvl:1,id:infinity},{lvl:10,id:unbreaking},{lvl:1,id:mending}]}

advancement revoke @s only saraka_potion:bow
recipe take @s saraka_potion:bow