clear @s knowledge_book 1

fill ~ ~-1 ~ ~15 ~-1 ~-15 cobblestone destroy

advancement revoke @s only saraka_potion:cobblestone_floor_x1z0
recipe take @s saraka_potion:cobblestone_floor_x1z0