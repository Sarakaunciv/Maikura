clear @s knowledge_book 1

give @s crossbow{Enchantments:{lvl:10,id:piercing},{lvl:5,id:quick_charge},[{lvl:1,id:multishot},{lvl:10,id:unbreaking},{lvl:1,id:mending}]}

advancement revoke @s only saraka_potion:crossb
recipe take @s saraka_potion:crossb