clear @s knowledge_book 1

give @s splash_potion{CustomPotionColor:38911,CustomPotionEffects:[{Id:30,Duration:12000}]}

advancement revoke @s only saraka_potion:dolphin
recipe take @s saraka_potion:dolphin