clear @s knowledge_book 1

give @s elytra{Enchantments:[{lvl:13,id:protection},{lvl:100,id:fire_protection},{lvl:10,id:unbreaking},{lvl:1,id:mending}]}

advancement revoke @s only saraka_potion:elitora
recipe take @s saraka_potion:elitora