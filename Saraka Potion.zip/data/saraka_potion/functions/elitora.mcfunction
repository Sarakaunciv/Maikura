clear @s knowledge_book 1

give @s elytra{Unbreakable:1,Enchantments:[{lvl:3,id:protection},{lvl:100,id:fire_protection}]}

advancement revoke @s only saraka_potion:elitora
recipe take @s saraka_potion:elitora