clear @s knowledge_book 1

summon experience_orb ~ ~ ~ {Value:8000}

advancement revoke @s only saraka_potion:exp_orb
recipe take @s saraka_potion:exp_orb