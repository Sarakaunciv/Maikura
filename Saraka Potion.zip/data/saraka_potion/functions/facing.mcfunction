clear @s knowledge_book 1

execute if entity @s[y_rotation=45..135,x_rotation=-90..-30] run tp @s ~ ~ ~ 90 -90
execute if entity @s[y_rotation=135..-135,x_rotation=-90..-30] run tp @s ~ ~ ~ 180 -90
execute if entity @s[y_rotation=-135..-45,x_rotation=-90..-30] run tp @s ~ ~ ~ -90 -90
execute if entity @s[y_rotation=-45..45,x_rotation=-90..-30] run tp @s ~ ~ ~ 0 -90

execute if entity @s[y_rotation=45..135,x_rotation=-30..30] run tp @s ~ ~ ~ 90 0
execute if entity @s[y_rotation=135..-135,x_rotation=-30..30] run tp @s ~ ~ ~ 180 0
execute if entity @s[y_rotation=-135..-45,x_rotation=-30..30] run tp @s ~ ~ ~ -90 0
execute if entity @s[y_rotation=-45..45,x_rotation=-30..30] run tp @s ~ ~ ~ 0 0

execute if entity @s[y_rotation=45..135,x_rotation=30..90] run tp @s ~ ~ ~ 90 90
execute if entity @s[y_rotation=135..-135,x_rotation=30..90] run tp @s ~ ~ ~ 180 90
execute if entity @s[y_rotation=-135..-45,x_rotation=30..90] run tp @s ~ ~ ~ -90 90
execute if entity @s[y_rotation=-45..45,x_rotation=30..90] run tp @s ~ ~ ~ 0 90

advancement revoke @s only saraka_potion:facing
recipe take @s saraka_potion:facing