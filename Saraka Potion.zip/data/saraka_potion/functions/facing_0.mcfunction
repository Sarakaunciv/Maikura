clear @s knowledge_book 1

tp @s ~ ~ ~ 0 0

advancement revoke @s only saraka_potion:facing_0
recipe take @s saraka_potion:facing_0