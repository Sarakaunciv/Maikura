clear @s knowledge_book 1

tp @s ~ ~ ~ 180 0

advancement revoke @s only saraka_potion:facing_180
recipe take @s saraka_potion:facing_180