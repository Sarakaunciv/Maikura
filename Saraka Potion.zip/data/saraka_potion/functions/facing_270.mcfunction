clear @s knowledge_book 1

tp @s ~ ~ ~ -90 0

advancement revoke @s only saraka_potion:facing_270
recipe take @s saraka_potion:facing_270