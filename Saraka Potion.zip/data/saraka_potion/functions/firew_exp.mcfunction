clear @s knowledge_book 1

give @s firework_rocket{Fireworks:{Flight:5,Explosions:[{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]},{Colors:[I;0]}]}} 16

advancement revoke @s only saraka_potion:firew_exp
recipe take @s saraka_potion:firew_exp