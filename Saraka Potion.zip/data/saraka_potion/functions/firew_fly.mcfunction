clear @s knowledge_book 1

give @s firework_rocket{Fireworks:{Flight:100}} 64

advancement revoke @s only saraka_potion:firew_fly
recipe take @s saraka_potion:firew_fly