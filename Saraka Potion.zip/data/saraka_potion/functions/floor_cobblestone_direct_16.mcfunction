clear @s knowledge_book 1

fill ^ ^-1 ^ ^ ^-1 ^15 cobblestone

advancement revoke @s only saraka_potion:floor_cobblestone_direct_16
recipe take @s saraka_potion:floor_cobblestone_direct_16