clear @s knowledge_book 1

fill ^ ^-1 ^1 ^ ^-1 ^32 cobblestone

advancement revoke @s only saraka_potion:floor_cobblestone_direct_32
recipe take @s saraka_potion:floor_cobblestone_direct_32