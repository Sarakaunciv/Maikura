clear @s knowledge_book 1

function saraka_potion:0_function_facing

schedule function saraka_potion:1_function_floor_cobblestone_direct_32 5t replace

advancement revoke @s only saraka_potion:floor_cobblestone_direct_32
recipe take @s saraka_potion:floor_cobblestone_direct_32