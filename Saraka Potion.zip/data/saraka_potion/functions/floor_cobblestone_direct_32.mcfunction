clear @s knowledge_book 1

function saraka_potion:0_function_facing

fill ^ ^-1 ^1 ^ ^-1 ^31 cobblestone

advancement revoke @s only saraka_potion:floor_cobblestone_direct_32
recipe take @s saraka_potion:floor_cobblestone_direct_32