clear @s knowledge_book 1

execute if entity @s[y_rotation=45..135] run tp @s ~ ~ ~ 90 0
execute if entity @s[y_rotation=135..-135] run tp @s ~ ~ ~ 180 0
execute if entity @s[y_rotation=-135..-45] run tp @s ~ ~ ~ -90 0
execute if entity @s[y_rotation=-45..45] run tp @s ~ ~ ~ 0 0

fill ^ ^-1 ^1 ^ ^-1 ^7 cobblestone

advancement revoke @s only saraka_potion:floor_cobblestone_direct_8
recipe take @s saraka_potion:floor_cobblestone_direct_8