clear @s knowledge_book 1

function saraka_potion:0_function_facing

fill ^ ^-1 ^1 ^ ^-1 ^7 cobblestone

advancement revoke @s only saraka_potion:floor_cobblestone_direct_8
recipe take @s saraka_potion:floor_cobblestone_direct_8