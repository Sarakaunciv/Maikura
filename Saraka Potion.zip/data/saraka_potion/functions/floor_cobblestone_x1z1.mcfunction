clear @s knowledge_book 1

function saraka_potion:0_function_facing

fill ^ ^-1 ^ ^15 ^-1 ^15 cobblestone

advancement revoke @s only saraka_potion:floor_cobblestone_x1z1
recipe take @s saraka_potion:floor_cobblestone_x1z1