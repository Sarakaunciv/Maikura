clear @s knowledge_book 1

function saraka_potion:0_function_facing

schedule function saraka_potion:1_function_floor_dirt_x1z1 5t replace

advancement revoke @s only saraka_potion:floor_dirt_x1z1
recipe take @s saraka_potion:floor_dirt_x1z1