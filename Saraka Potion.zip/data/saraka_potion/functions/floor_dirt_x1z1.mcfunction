clear @s knowledge_book 1

function saraka_potion:0_function_facing

fil ^ ^-1 ^ ^15 ^-1 ^15 dirt

advancement revoke @s only saraka_potion:floor_dirt_x1z1
recipe take @s saraka_potion:floor_dirt_x1z1