clear @s knowledge_book 1

fill ^ ^-1 ^ ^31 ^-1 ^31 dirt

advancement revoke @s only saraka_potion:floor_dirt_x2z2
recipe take @s saraka_potion:floor_dirt_x2z2