clear @s knowledge_book 1

setblock ^ ^ ^ torch
setblock ^ ^ ^8 torch
setblock ^ ^ ^16 torch
setblock ^ ^ ^24 torch

advancement revoke @s only saraka_potion:floor_torch_1x4
recipe take @s saraka_potion:floor_torch_1x4