clear @s knowledge_book 1

setblock ^ ^ ^ torch
setblock ^ ^ ^8 torch
setblock ^ ^ ^16 torch
setblock ^ ^ ^24 torch
setblock ^ ^ ^32 torch
setblock ^ ^ ^40 torch
setblock ^ ^ ^48 torch
setblock ^ ^ ^56 torch

advancement revoke @s only saraka_potion:floor_torch_1x8
recipe take @s saraka_potion:floor_torch_1x8