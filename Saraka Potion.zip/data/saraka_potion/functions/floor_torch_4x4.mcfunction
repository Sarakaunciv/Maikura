clear @s knowledge_book 1

setblock ^ ^ ^ torch
setblock ^ ^ ^8 torch
setblock ^ ^ ^16 torch
setblock ^ ^ ^24 torch
setblock ^8 ^ ^ torch
setblock ^8 ^ ^8 torch
setblock ^8 ^ ^16 torch
setblock ^8 ^ ^24 torch
setblock ^16 ^ ^ torch
setblock ^16 ^ ^8 torch
setblock ^16 ^ ^16 torch
setblock ^16 ^ ^24 torch
setblock ^24 ^ ^ torch
setblock ^24 ^ ^8 torch
setblock ^24 ^ ^16 torch
setblock ^24 ^ ^24 torch

advancement revoke @s only saraka_potion:floor_torch_4x4
recipe take @s saraka_potion:floor_torch_4x4