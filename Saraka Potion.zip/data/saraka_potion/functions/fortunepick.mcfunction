clear @s knowledge_book 1

give @s netherite_pickaxe{Enchantments:[{lvl:255,id:fortune},{lvl:5,id:efficiency},{lvl:10,id:unbreaking},{lvl:1,id:mending}]}

advancement revoke @s only saraka_potion:fortunepick
recipe take @s saraka_potion:fortunepick