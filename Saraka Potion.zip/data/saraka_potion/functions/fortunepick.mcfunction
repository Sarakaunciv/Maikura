clear @s knowledge_book 1

give @s netherite_pickaxe{Enchantments:[{lvl:40,id:fortune},{lvl:10,id:efficiency},{lvl:3,id:unbreaking},{lvl:1,id:mending}]}

advancement revoke @s only saraka_potion:fortunepick
recipe take @s saraka_potion:fortunepick