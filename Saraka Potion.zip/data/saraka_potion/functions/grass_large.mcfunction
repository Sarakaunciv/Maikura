clear @s knowledge_book 1

fill ~-16 ~-1 ~-16 ~16 ~3 ~16 grass_block replace dirt

advancement revoke @s only saraka_potion:grass_large
recipe take @s saraka_potion:grass_large