clear @s knowledge_book 1

fill ~-4 ~-1 ~-4 ~4 ~3 ~4 grass_block replace dirt

advancement revoke @s only saraka_potion:grass_small
recipe take @s saraka_potion:grass_small