clear @s knowledge_book 1

give @s potion{CustomPotionColor:16776960,CustomPotionEffects:[{Id:3,Duration:12000,Amplifier:19}]}

advancement revoke @s only saraka_potion:haste20
recipe take @s saraka_potion:haste20