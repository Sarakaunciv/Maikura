clear @s knowledge_book 1

give @s splash_potion{CustomPotionColor:65280,CustomPotionEffects:[{Id:32,Duration:72000,Amplifier:9}]}

advancement revoke @s only saraka_potion:hero10
recipe take @s saraka_potion:hero10