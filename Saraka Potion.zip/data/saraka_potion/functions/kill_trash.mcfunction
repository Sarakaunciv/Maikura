clear @s knowledge_book 1

kill @e[type=minecraft:small_fireball]
kill @e[type=minecraft:fireball]
kill @e[type=minecraft:firework_rocket]

advancement revoke @s only saraka_potion:kill_trash
recipe take @s saraka_potion:kill_trash