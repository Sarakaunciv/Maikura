clear @s knowledge_book 1

give @s splash_potion{CustomPotionColor:16777215,CustomPotionEffects:[{Id:25,Duration:12000,Amplifier:251}]}

advancement revoke @s only saraka_potion:levita
recipe take @s saraka_potion:levita