clear @s knowledge_book 1

give @s netherite_sword{Enchantments:[{lvl:255,id:looting},{lvl:10,id:sharpness},{lvl:5,id:sweeping},{lvl:10,id:unbreaking},{lvl:1,id:mending}]}

advancement revoke @s only saraka_potion:lootsword
recipe take @s saraka_potion:lootsword