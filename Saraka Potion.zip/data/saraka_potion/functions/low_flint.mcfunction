clear @s knowledge_book 1

give @s flint_and_steel{Unbreakable:1}

advancement revoke @s only saraka_potion:low_flint
recipe take @s saraka_potion:low_flint