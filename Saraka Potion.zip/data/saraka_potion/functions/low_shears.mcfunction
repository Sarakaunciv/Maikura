clear @s knowledge_book 1

give @s shears{Enchantments:[{lvl:10,id:efficiency}],Unbreakable:1}

advancement revoke @s only saraka_potion:low_shears
recipe take @s saraka_potion:low_shears