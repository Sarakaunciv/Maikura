clear @s knowledge_book 1

give @s shield{Unbreakable:1}

advancement revoke @s only saraka_potion:low_shield
recipe take @s saraka_potion:low_shield