clear @s knowledge_book 1

give @s rad_mod:rad_chestplate{Enchantments:[{lvl:5,id:protection},{lvl:100,id:fire_protection},{lvl:5,id:unbreaking},{lvl:1,id:mending}]}

advancement revoke @s only saraka_potion:rad_a_chest_buff
recipe take @s saraka_potion:rad_a_chest_buff