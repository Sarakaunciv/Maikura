clear @s knowledge_book 1

give @s rad_mod:rad_leggings{Enchantments:[{lvl:5,id:protection},{lvl:5,id:swift_sneak},{lvl:5,id:unbreaking},{lvl:1,id:mending}]}

advancement revoke @s only saraka_potion:rad_a_leg_buff
recipe take @s saraka_potion:rad_a_leg_buff