clear @s knowledge_book 1

give @s rad_mod:rad_boots{Enchantments:[{lvl:5,id:protection},{lvl:3,id:depth_strider},{lvl:3,id:soul_speed},{lvl:3,id:unbreaking},{lvl:1,id:mending}]}

advancement revoke @s only saraka_potion:rad_boots_buff
recipe take @s saraka_potion:rad_boots_buff