clear @s knowledge_book 1

give @s rad_mod:rad_helmet{Enchantments:[{lvl:5,id:protection},{lvl:5,id:fire_protection},{lvl:10,id:respiration},{lvl:1,id:aqua_affinity},{lvl:3,id:unbreaking},{lvl:1,id:mending}]}

advancement revoke @s only saraka_potion:rad_helmet_buff
recipe take @s saraka_potion:rad_helmet_buff