clear @s knowledge_book 1

give @s rad_mod:rad_pickaxe{Enchantments:[{lvl:29,id:sharpness},{lvl:5,id:efficiency},{lvl:3,id:unbreaking},{lvl:1,id:mending}]}

advancement revoke @s only saraka_potion:rad_t_pick_buff
recipe take @s saraka_potion:rad_t_pick_buff