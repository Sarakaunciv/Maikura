clear @s knowledge_book 1

give @s rad_mod:rad_sword{Enchantments:[{lvl:59,id:sharpness},{lvl:5,id:looting},{lvl:255,id:sweeping},{lvl:3,id:unbreaking},{lvl:1,id:mending}]}

advancement revoke @s only saraka_potion:rad_t_sword_buff
recipe take @s saraka_potion:rad_t_sword_buff