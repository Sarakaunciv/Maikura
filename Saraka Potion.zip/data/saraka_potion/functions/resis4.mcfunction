clear @s knowledge_book 1

give @s splash_potion{CustomPotionColor:5592440,CustomPotionEffects:[{Id:11,Duration:72000,Amplifier:3}]}

advancement revoke @s only saraka_potion:resis4
recipe take @s saraka_potion:resis4