clear @s knowledge_book 1

give @s netherite_sword{Enchantments:[{lvl:23,id:sharpness},{lvl:9,id:looting},{lvl:255,id:sweeping},{lvl:3,id:unbreaking},{lvl:1,id:mending}]}

advancement revoke @s only saraka_potion:sword_loot
recipe take @s saraka_potion:sword_loot