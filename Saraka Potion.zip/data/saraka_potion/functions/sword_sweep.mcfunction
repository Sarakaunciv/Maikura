clear @s knowledge_book 1

give @s stone_sword{Enchantments:[{lvl:10,id:sharpness},{lvl:5,id:looting},{lvl:255,id:sweeping}]}

advancement revoke @s only saraka_potion:sword_sweep
recipe take @s saraka_potion:sword_sweep