clear @s knowledge_book 1

give @s iron_sword{Enchantments:[{lvl:19,id:sharpness},{lvl:255,id:sweeping},{lvl:10,id:unbreaking}]}

advancement revoke @s only saraka_potion:sword_sweep_0
recipe take @s saraka_potion:sword_sweep_0