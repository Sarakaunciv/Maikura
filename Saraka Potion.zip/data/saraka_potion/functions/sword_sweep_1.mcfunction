clear @s knowledge_book 1

give @s diamond_sword{Enchantments:[{lvl:35,id:sharpness},{lvl:255,id:sweeping},{lvl:10,id:efficiency},{lvl:3,id:unbreaking}]}

advancement revoke @s only saraka_potion:sword_sweep_1
recipe take @s saraka_potion:sword_sweep_1