clear @s knowledge_book 1

give @s diamond_sword{Enchantments:[{lvl:71,id:sharpness},{lvl:255,id:sweeping},{lvl:10,id:unbreaking}]}

advancement revoke @s only saraka_potion:sword_sweep_2
recipe take @s saraka_potion:sword_sweep_2