clear @s knowledge_book 1

weather thunder

advancement revoke @s only saraka_potion:thunder
recipe take @s saraka_potion:thunder