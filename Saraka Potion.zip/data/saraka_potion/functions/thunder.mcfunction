clear @s knowledge_book 1

weather thunder
give @s trident{Enchantments:[{lvl:1,id:channeling}],Damage:248}

advancement revoke @s only saraka_potion:thunder
recipe take @s saraka_potion:thunder