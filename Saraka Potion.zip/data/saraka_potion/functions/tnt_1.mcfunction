clear @s knowledge_book 1

fill ~-2 ~-1 ~-2 ~2 ~3 ~2 air destroy

advancement revoke @s only saraka_potion:tnt_1
recipe take @s saraka_potion:tnt_1