clear @s knowledge_book 1

give @s minecraft:command_block{BlockEntityTag: {auto: 1b, Command: 'fill ~-2 ~-1 ~-2 ~2 ~3 ~2 air destroy', id: "minecraft:command_block"}, display: {Name: '{"text":"Destroy y-1 5x5"}'}} 8

advancement revoke @s only saraka_potion:tnt_1
recipe take @s saraka_potion:tnt_1