clear @s knowledge_book 1

give @s minecraft:dispenser{display: {Name: '{"text":"Destroy y-1 5x5"}'}} 8

advancement revoke @s only saraka_potion:tnt_1
recipe take @s saraka_potion:tnt_1