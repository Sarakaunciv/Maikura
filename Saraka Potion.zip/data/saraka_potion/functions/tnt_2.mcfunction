clear @s knowledge_book 1

give @s minecraft:command_block{BlockEntityTag: {auto: 1b, Command: 'fill ~-7 ~-1 ~-7 ~7 ~13 ~7 air destroy', id: "minecraft:command_block"}, display: {Name: '{"text":"Destroy y-1 15x15"}'}} 4

advancement revoke @s only saraka_potion:tnt_2
recipe take @s saraka_potion:tnt_2