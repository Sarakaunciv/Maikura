clear @s knowledge_book 1

fill ~-6 ~-1 ~-6 ~6 ~11 ~6 air destroy

advancement revoke @s only saraka_potion:tnt_2
recipe take @s saraka_potion:tnt_2