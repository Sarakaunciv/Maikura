clear @s knowledge_book 1

fill ~-7 ~-1 ~-7 ~7 ~13 ~7 air destroy

advancement revoke @s only saraka_potion:tnt_2
recipe take @s saraka_potion:tnt_2