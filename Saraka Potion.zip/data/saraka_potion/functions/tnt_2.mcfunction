clear @s knowledge_book 1

give @s minecraft:dispenser{display: {Name: '{"text":"Destroy y-1 15x15"}'}} 4

advancement revoke @s only saraka_potion:tnt_2
recipe take @s saraka_potion:tnt_2