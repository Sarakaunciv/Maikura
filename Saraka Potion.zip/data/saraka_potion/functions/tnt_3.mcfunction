clear @s knowledge_book 1

fill ~-10 ~-1 ~-10 ~10 ~19 ~10 air destroy

advancement revoke @s only saraka_potion:tnt_3
recipe take @s saraka_potion:tnt_3