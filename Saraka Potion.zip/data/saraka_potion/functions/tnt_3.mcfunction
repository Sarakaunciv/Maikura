clear @s knowledge_book 1

fill ~-15 ~-1 ~-15 ~15 ~29 ~15 air destroy

advancement revoke @s only saraka_potion:tnt_3
recipe take @s saraka_potion:tnt_3