clear @s knowledge_book 1

give @s minecraft:command_block{BlockEntityTag: {powered: 0b, Command: "fill ~ ~-1 ~ ~ ~ ~ air destroy", id: "minecraft:command_block"}, display: {Name: '{"text":"Destroy y-1 31x31"}'}} 2
fill ~-15 ~-1 ~-15 ~15 ~29 ~15 air destroy

advancement revoke @s only saraka_potion:tnt_3
recipe take @s saraka_potion:tnt_3