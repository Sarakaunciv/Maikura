clear @s knowledge_book 1

give @s minecraft:dispenser{display: {Name: '{"text":"Destroy y-1 31x31"}'}} 2

advancement revoke @s only saraka_potion:tnt_3
recipe take @s saraka_potion:tnt_3