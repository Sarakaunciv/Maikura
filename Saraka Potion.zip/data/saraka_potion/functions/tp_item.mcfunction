clear @s knowledge_book 1

tp @e[type=item] ~ ~ ~

advancement revoke @s only saraka_potion:kill_item
recipe take @s saraka_potion:kill_item