clear @s knowledge_book 1

give @s trident{Enchantments:[{lvl:16,id:riptide},{lvl:10,id:unbreaking},{lvl:1,id:mending}]}

advancement revoke @s only saraka_potion:trident
recipe take @s saraka_potion:trident