data modify storage villagerinfstock:main VillagerTemp set from entity @s Inventory
item replace entity @s villager.0 with minecraft:air
item replace entity @s villager.1 with minecraft:air
item replace entity @s villager.2 with minecraft:air
item replace entity @s villager.3 with minecraft:air
item replace entity @s villager.4 with minecraft:air
item replace entity @s villager.5 with minecraft:air
item replace entity @s villager.6 with minecraft:air
item replace entity @s villager.7 with minecraft:air
