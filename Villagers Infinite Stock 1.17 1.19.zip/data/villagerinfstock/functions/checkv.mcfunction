execute store result score $temp villagerinfstock run data get entity @s Offers.Recipes

execute if score $temp villagerinfstock matches 0 unless score @s villagerinfstock matches 0 run tag @s remove infstock
execute if score $temp villagerinfstock matches 0 unless score @s villagerinfstock matches 0 run tag @s remove noexp

execute if score $temp villagerinfstock > @s villagerinfstock run function villagerinfstock:updatev

execute if score $villagers villagerinfstock matches 1.. if entity @s[tag=!infstock,nbt={Offers:{}}] run function villagerinfstock:updatev
execute if score $rewardexp villagerinfstock matches 1.. if entity @s[tag=!noexp,nbt={Offers:{}}] run function villagerinfstock:updatev

scoreboard players operation @s villagerinfstock = $temp villagerinfstock
