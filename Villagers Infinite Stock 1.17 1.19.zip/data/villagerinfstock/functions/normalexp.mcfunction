function villagerinfstock:bugfix

data modify entity @s Offers.Recipes[].rewardExp set value 1b
tag @s remove noexp

data modify entity @s Inventory set from storage villagerinfstock:main VillagerTemp
data modify storage villagerinfstock:main VillagerTemp set value []
