function villagerinfstock:bugfix

data modify entity @s Offers.Recipes[].uses set value 0
tag @s remove infstock

data modify entity @s Inventory set from storage villagerinfstock:main VillagerTemp
data modify storage villagerinfstock:main VillagerTemp set value []
