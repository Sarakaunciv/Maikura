scoreboard players add @e[type=#villagerinfstock:infstock] villagerinfstock 0
execute if score $checkv villagerinfstock matches 1 as @e[type=minecraft:villager] run function villagerinfstock:checkv
execute if score $checkw villagerinfstock matches 1 as @e[type=minecraft:wandering_trader] run function villagerinfstock:checkw

execute if score $villagers villagerinfstock matches 1.. as @a[scores={villagerinfstock=1..}] at @s as @e[distance=..10,type=minecraft:villager,nbt={Offers:{}}] run function villagerinfstock:updatestock
execute if score $wanderingtrader villagerinfstock matches 1.. as @a[scores={villagerinfstock=1..}] at @s as @e[distance=..10,type=minecraft:wandering_trader,nbt={Offers:{}}] run function villagerinfstock:updatestock
scoreboard players set @a[scores={villagerinfstock=1..}] villagerinfstock 0

execute if score $villagers villagerinfstock matches ..0 as @e[type=minecraft:villager,tag=infstock,nbt={Offers:{}}] run function villagerinfstock:normalstock
execute if score $wanderingtrader villagerinfstock matches ..0 as @e[type=minecraft:wandering_trader,tag=infstock,nbt={Offers:{}}] run function villagerinfstock:normalstock
execute if score $rewardexp villagerinfstock matches ..0 as @e[type=#villagerinfstock:infstock,tag=noexp,nbt={Offers:{}}] run function villagerinfstock:normalexp
