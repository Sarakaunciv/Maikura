execute store result score $scf villagerinfstock run gamerule sendCommandFeedback
execute if score $scf villagerinfstock matches 1 run schedule function villagerinfstock:scftrue 1t replace
execute if score $scf villagerinfstock matches 1 run gamerule sendCommandFeedback false
