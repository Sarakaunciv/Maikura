scoreboard objectives add villagerinfstock minecraft.custom:minecraft.traded_with_villager

scoreboard players add $villagers villagerinfstock 0
scoreboard players add $wanderingtrader villagerinfstock 0
scoreboard players add $rewardexp villagerinfstock 0

scoreboard players add $checkv villagerinfstock 0
scoreboard players add $checkw villagerinfstock 0

data merge storage villagerinfstock:main {VillagerTemp:[]}

schedule function villagerinfstock:setupmsg 2s replace
