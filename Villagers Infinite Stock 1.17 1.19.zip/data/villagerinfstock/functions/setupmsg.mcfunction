tellraw @a [{"text":"\nVillagers Infinite Stock Datapack Installed!\n","color":"gold","underlined":"true","bold":true}]

tellraw @a [{"text":"To toggle Villagers infinite stock, click ","color":"yellow"},{"color":"dark_gray","bold":true,"text":"HERE","clickEvent":{"action":"run_command","value":"/function villagerinfstock:toggle.villagers"}},{"text":".","color":"gray","bold":false}]
tellraw @a [{"text":"To toggle Wandering Traders infinite stock, click ","color":"yellow"},{"color":"dark_gray","bold":true,"text":"HERE","clickEvent":{"action":"run_command","value":"/function villagerinfstock:toggle.wanderingtraders"}},{"text":".\n","color":"gray","bold":false}]

tellraw @a [{"text":"To toggle experience orb reward for trading, click ","color":"yellow"},{"color":"dark_gray","bold":true,"text":"HERE","clickEvent":{"action":"run_command","value":"/function villagerinfstock:toggle.rewardexp"}},{"text":".\n","color":"gray","bold":false}]

tellraw @a [{"text":"To uninstall this datapack, click ","color":"gray"},{"color":"dark_gray","bold":true,"text":"HERE","clickEvent":{"action":"run_command","value":"/function villagerinfstock:uninstall_datapack"}},{"text":".\n","color":"gray","bold":false}]
