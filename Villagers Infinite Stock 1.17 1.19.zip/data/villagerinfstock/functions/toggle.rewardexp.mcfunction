function villagerinfstock:scfbypass

execute if score $rewardexp villagerinfstock matches ..-1 run scoreboard players set $rewardexp villagerinfstock 0
scoreboard players add $rewardexp villagerinfstock 1
execute if score $rewardexp villagerinfstock matches 2.. run scoreboard players set $rewardexp villagerinfstock 0

execute if score $rewardexp villagerinfstock matches 0 run tellraw @a [{"text":"\nExperience reward for trading has been ","color":"gray"},{"text":"enabled","bold":true},{"text":".\n","bold":false}]
execute if score $rewardexp villagerinfstock matches 1 run tellraw @a [{"text":"\nExperience reward for trading has been ","color":"gray"},{"text":"disabled","bold":true},{"text":".\n","bold":false}]

execute if score $villagers villagerinfstock matches 1.. run scoreboard players set $checkv villagerinfstock 1
execute if score $rewardexp villagerinfstock matches 1.. run scoreboard players set $checkv villagerinfstock 1
execute if score $villagers villagerinfstock matches ..0 if score $rewardexp villagerinfstock matches ..0 run scoreboard players set $checkv villagerinfstock 0
execute if score $wanderingtrader villagerinfstock matches 1.. run scoreboard players set $checkw villagerinfstock 1
execute if score $rewardexp villagerinfstock matches 1.. run scoreboard players set $checkw villagerinfstock 1
execute if score $wanderingtrader villagerinfstock matches ..0 if score $rewardexp villagerinfstock matches ..0 run scoreboard players set $checkw villagerinfstock 0
