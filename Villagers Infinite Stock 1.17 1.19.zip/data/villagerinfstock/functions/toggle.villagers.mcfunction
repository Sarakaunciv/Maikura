function villagerinfstock:scfbypass

execute if score $villagers villagerinfstock matches ..-1 run scoreboard players set $villagers villagerinfstock 0
scoreboard players add $villagers villagerinfstock 1
execute if score $villagers villagerinfstock matches 2.. run scoreboard players set $villagers villagerinfstock 0

execute if score $villagers villagerinfstock matches 0 run tellraw @a [{"text":"\nInfinite stock for Villagers has been ","color":"gray"},{"text":"disabled","bold":true},{"text":".\n","bold":false}]
execute if score $villagers villagerinfstock matches 1 run tellraw @a [{"text":"\nInfinite stock for Villagers has been ","color":"gray"},{"text":"enabled","bold":true},{"text":".\n","bold":false}]

execute if score $villagers villagerinfstock matches 1.. run scoreboard players set $checkv villagerinfstock 1
execute if score $rewardexp villagerinfstock matches 1.. run scoreboard players set $checkv villagerinfstock 1
execute if score $villagers villagerinfstock matches ..0 if score $rewardexp villagerinfstock matches ..0 run scoreboard players set $checkv villagerinfstock 0
