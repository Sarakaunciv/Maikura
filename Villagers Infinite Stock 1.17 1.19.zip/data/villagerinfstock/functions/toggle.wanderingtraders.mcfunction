function villagerinfstock:scfbypass

execute if score $wanderingtrader villagerinfstock matches ..-1 run scoreboard players set $wanderingtrader villagerinfstock 0
scoreboard players add $wanderingtrader villagerinfstock 1
execute if score $wanderingtrader villagerinfstock matches 2.. run scoreboard players set $wanderingtrader villagerinfstock 0

execute if score $wanderingtrader villagerinfstock matches 0 run tellraw @a [{"text":"\nInfinite stock for Wandering Traders has been ","color":"gray"},{"text":"disabled","bold":true},{"text":".\n","bold":false}]
execute if score $wanderingtrader villagerinfstock matches 1 run tellraw @a [{"text":"\nInfinite stock for Wandering Traders has been ","color":"gray"},{"text":"enabled","bold":true},{"text":".\n","bold":false}]

execute if score $wanderingtrader villagerinfstock matches 1.. run scoreboard players set $checkw villagerinfstock 1
execute if score $rewardexp villagerinfstock matches 1.. run scoreboard players set $checkw villagerinfstock 1
execute if score $wanderingtrader villagerinfstock matches ..0 if score $rewardexp villagerinfstock matches ..0 run scoreboard players set $checkw villagerinfstock 0
