function villagerinfstock:scfbypass

execute if score $villagers villagerinfstock matches 0 run tellraw @a [{"text":"\nInfinite stock for Villagers is ","color":"gray"},{"text":"disabled","bold":true},{"text":".","bold":false}]
execute if score $villagers villagerinfstock matches 1 run tellraw @a [{"text":"\nInfinite stock for Villagers is ","color":"gray"},{"text":"enabled","bold":true},{"text":".","bold":false}]

execute if score $wanderingtrader villagerinfstock matches 0 run tellraw @a [{"text":"Infinite stock for Wandering Traders is ","color":"gray"},{"text":"disabled","bold":true},{"text":".","bold":false}]
execute if score $wanderingtrader villagerinfstock matches 1 run tellraw @a [{"text":"Infinite stock for Wandering Traders is ","color":"gray"},{"text":"enabled","bold":true},{"text":".","bold":false}]

execute if score $rewardexp villagerinfstock matches 0 run tellraw @a [{"text":"Experience reward for trading is ","color":"gray"},{"text":"enabled","bold":true},{"text":".\n","bold":false}]
execute if score $rewardexp villagerinfstock matches 1 run tellraw @a [{"text":"Experience reward for trading is ","color":"gray"},{"text":"disabled","bold":true},{"text":".\n","bold":false}]
