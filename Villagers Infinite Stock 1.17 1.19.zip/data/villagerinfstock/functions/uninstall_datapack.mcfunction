function villagerinfstock:scfbypass

execute as @e[type=#villagerinfstock:infstock,tag=infstock] run function villagerinfstock:vnir
execute as @e[type=#villagerinfstock:infstock,tag=noexp] run function villagerinfstock:exp

scoreboard objectives remove villagerinfstock

data remove storage villagerinfstock:main VillagerTemp

tellraw @s [{"text":"\nVillagers Infinite Stock Datapack was uninstalled.\n","color":"gray","bold":true},{"text":"Remove the datapack before the next ","bold":false},{"text":"/reload","color":"dark_gray","bold":true,"clickEvent":{"action":"suggest_command","value":"/reload"}},{"text":", or disable it with ","color":"gray","bold":false},{"text":"/datapack disable","color":"dark_gray","bold":true,"clickEvent":{"action":"suggest_command","value":"/datapack disable"}},{"text":".\n","color":"gray","bold":false}]
