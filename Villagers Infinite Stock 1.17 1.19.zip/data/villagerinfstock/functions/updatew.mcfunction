function villagerinfstock:bugfix

execute if score $wanderingtrader villagerinfstock matches 1.. run data modify entity @s Offers.Recipes[].uses set value -2147483647
execute if score $wanderingtrader villagerinfstock matches 1.. run tag @s add infstock
execute if score $rewardexp villagerinfstock matches 1.. run data modify entity @s Offers.Recipes[].rewardExp set value 0b
execute if score $rewardexp villagerinfstock matches 1.. run tag @s add noexp

data modify entity @s Inventory set from storage villagerinfstock:main VillagerTemp
data modify storage villagerinfstock:main VillagerTemp set value []
