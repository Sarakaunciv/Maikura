For Minecraft 1.17-1.19

To activate the toggles, you can use the menu that appears after a /reload, or:
	/function villagerinfstock:toggle.villagers
	/function villagerinfstock:toggle.wanderingtraders
	/function villagerinfstock:toggle.rewardexp

To check the current toggle states, run:
	/function villagerinfstock:toggles

To uninstall the datapack run:
	/function villagerinfstock:uninstall_datapack
