clear @s knowledge_book 1

give SarakaMaikura minecraft:brown_shulker_box{display: {Name: '{"text":"Misc Buy"}'}, BlockEntityTag: {Items: [{Slot: 0b, id: "minecraft:dispenser", Count: 64b, tag: {display: {Name: '{"text":"Book Prot4 1000"}'}}},{Slot: 1b, id: "minecraft:dispenser", Count: 64b, tag: {display: {Name: '{"text":"Book Unbre3 200"}'}}},{Slot: 2b, id: "minecraft:dispenser", Count: 64b, tag: {display: {Name: '{"text":"Book Mend 500"}'}}}]}}

advancement revoke @s only saraka_shop:9_box_misc_buy
recipe take @s saraka_shop:9_box_misc_buy
