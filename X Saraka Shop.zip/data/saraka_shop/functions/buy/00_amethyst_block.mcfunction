
give @s minecraft:amethyst_block 1
scoreboard players remove @s s_c_t_0 80
