
give @s minecraft:diamond 1
scoreboard players remove @s s_c_t_0 20000
