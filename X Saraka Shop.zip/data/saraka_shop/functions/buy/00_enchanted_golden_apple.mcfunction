
give @s minecraft:enchanted_golden_apple 1
scoreboard players remove @s s_c_t_0 1600
