
give @s minecraft:gold_block 1
scoreboard players remove @s s_c_t_0 200
