
give @s minecraft:lapis_block 1
scoreboard players remove @s s_c_t_0 30
