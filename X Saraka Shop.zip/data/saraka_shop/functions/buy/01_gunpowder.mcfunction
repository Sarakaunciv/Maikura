
give @s minecraft:gunpowder 1
scoreboard players remove @s s_c_t_0 10
