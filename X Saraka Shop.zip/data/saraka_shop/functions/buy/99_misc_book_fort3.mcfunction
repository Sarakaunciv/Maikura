
give @s enchanted_book{StoredEnchantments:[{id:fortune,lvl:3}]} 1
scoreboard players remove @s s_c_t_0 500
