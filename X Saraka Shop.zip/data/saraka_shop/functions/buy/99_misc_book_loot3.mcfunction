
give @s enchanted_book{StoredEnchantments:[{id:looting,lvl:3}]} 1
scoreboard players remove @s s_c_t_0 2000
