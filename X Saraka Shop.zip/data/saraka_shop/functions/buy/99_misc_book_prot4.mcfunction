
give @s enchanted_book{StoredEnchantments:[{id:protection,lvl:4}]} 1
scoreboard players remove @s s_c_t_0 1000
