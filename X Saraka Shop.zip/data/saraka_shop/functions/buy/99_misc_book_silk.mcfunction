
give @s enchanted_book{StoredEnchantments:[{id:silk_touch,lvl:1}]} 1
scoreboard players remove @s s_c_t_0 150
