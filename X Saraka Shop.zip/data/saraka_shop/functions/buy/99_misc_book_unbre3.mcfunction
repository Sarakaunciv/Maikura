
give @s enchanted_book{StoredEnchantments:[{id:unbreaking,lvl:3}]} 1
scoreboard players remove @s s_c_t_0 200
