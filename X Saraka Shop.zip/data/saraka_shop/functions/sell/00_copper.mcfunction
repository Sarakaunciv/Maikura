
clear @s minecraft:copper_block 1
scoreboard players add @s s_c_t_0 50
