
clear @s minecraft:enchanted_golden_apple 1
scoreboard players add @s s_c_t_0 1600
