
clear @s minecraft:iron_block 1
scoreboard players add @s s_c_t_0 100
