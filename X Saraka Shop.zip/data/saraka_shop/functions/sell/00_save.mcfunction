
clear @s minecraft:structure_block 1
scoreboard players add @s s_c_t_0 100000000
