
clear @s minecraft:ender_pearl 1
scoreboard players add @s s_c_t_0 25
