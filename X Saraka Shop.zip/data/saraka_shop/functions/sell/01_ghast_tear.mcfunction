
clear @s minecraft:ghast_tear 1
scoreboard players add @s s_c_t_0 15
