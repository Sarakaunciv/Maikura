
clear @s minecraft:gunpowder 1
scoreboard players add @s s_c_t_0 10
