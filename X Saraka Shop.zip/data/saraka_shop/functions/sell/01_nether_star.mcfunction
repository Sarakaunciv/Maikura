
clear @s minecraft:nether_star 1
scoreboard players add @s s_c_t_0 200000
