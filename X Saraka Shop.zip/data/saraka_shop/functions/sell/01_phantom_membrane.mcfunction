
clear @s minecraft:phantom_membrane 1
scoreboard players add @s s_c_t_0 20
