
clear @s minecraft:sculk_catalyst 1
scoreboard players add @s s_c_t_0 10000000
