
clear @s minecraft:spider_eye 1
scoreboard players add @s s_c_t_0 8
