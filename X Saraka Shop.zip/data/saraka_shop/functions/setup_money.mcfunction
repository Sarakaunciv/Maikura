
scoreboard objectives add s_c_t_0 trigger
scoreboard objectives setdisplay sidebar s_c_t_0
scoreboard players set SarakaMaikura s_c_t_0 0
