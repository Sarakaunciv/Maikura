
execute as @e[type=#saraka_eff_any] unless score @s saraka_eff matches 1 run scoreboard players enable @s saraka_eff

execute as @e[type=#saraka_eff_any,scores={saraka_eff=0}] run effect give @s resistance 3600 2 true
execute as @e[type=#saraka_eff_any,scores={saraka_eff=0}] run effect give @s absorption 3600 4 true
execute as @e[type=#saraka_eff_speed,scores={saraka_eff=0}] run effect give @s speed 3600 1 true
execute as @e[type=#saraka_eff_strength,scores={saraka_eff=0}] run effect give @s strength 3600 2 true

execute as @e[type=#saraka_eff_any,scores={saraka_eff=0}] run scoreboard players set @s saraka_eff 1
