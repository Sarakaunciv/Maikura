
execute as @e[type=#saraka_eqm_any] unless score @s saraka_eqm matches 1 run scoreboard players enable @s saraka_eqm
execute as @e[type=#saraka_eqm_any,scores={saraka_eqm=0}] run loot replace entity @s armor.chest loot saraka_eqm:chests/armor_chestplate
execute as @e[type=#saraka_eqm_any,scores={saraka_eqm=0}] run loot replace entity @s armor.head loot saraka_eqm:chests/armor_helmet
execute as @e[type=#saraka_eqm_any,scores={saraka_eqm=0}] run loot replace entity @s armor.legs loot saraka_eqm:chests/armor_leggings
execute as @e[type=#saraka_eqm_any,scores={saraka_eqm=0}] run loot replace entity @s armor.feet loot saraka_eqm:chests/armor_boots

execute as @e[type=#saraka_eqm_bow,scores={saraka_eqm=0}] run loot replace entity @s weapon.mainhand loot saraka_eqm:chests/hand_main_bow
execute as @e[type=#saraka_eqm_crossbow,scores={saraka_eqm=0}] run loot replace entity @s weapon.mainhand loot saraka_eqm:chests/hand_main_crossbow
execute as @e[type=#saraka_eqm_melee,scores={saraka_eqm=0}] run loot replace entity @s weapon.mainhand loot saraka_eqm:chests/hand_main_melee

execute as @e[type=#saraka_eqm_any,scores={saraka_eqm=0}] run loot replace entity @s weapon.offhand loot mer:chests/weapon
execute as @e[type=#saraka_eqm_any,nbt={ArmorItems:[{},{},{},{}],HandItems:[{},{}]},scores={saraka_eqm=0}] run scoreboard players set @s saraka_eqm 1
