
execute as @e[type=#saraka_eqm_any] unless score @s saraka_eqm matches 1 run scoreboard players enable @s saraka_eqm

execute as @e[type=#saraka_eqm_bow,scores={saraka_eqm=0}] run loot replace entity @s weapon.mainhand loot saraka_eqm:chests/bow

execute as @e[type=#saraka_eqm_loot_1,scores={saraka_eqm=0}] run loot replace entity @s weapon.offhand loot saraka_eqm:chests/loot_1
execute as @e[type=#saraka_eqm_loot_2,scores={saraka_eqm=0}] run loot replace entity @s weapon.offhand loot saraka_eqm:chests/loot_2

execute as @e[type=#saraka_eqm_resis_3,scores={saraka_eqm=0}] run effect give @s resistance 3600 2 true
execute as @e[type=#saraka_eqm_resis_4,scores={saraka_eqm=0}] run effect give @s resistance 3600 3 true
execute as @e[type=#saraka_eqm_speed_2,scores={saraka_eqm=0}] run effect give @s speed 3600 1 true
execute as @e[type=#saraka_eqm_speed_5,scores={saraka_eqm=0}] run effect give @s speed 3600 4 true
execute as @e[type=#saraka_eqm_strength_3,scores={saraka_eqm=0}] run effect give @s strength 3600 2 true
execute as @e[type=#saraka_eqm_strength_6,scores={saraka_eqm=0}] run effect give @s strength 3600 5 true

execute as @e[type=#saraka_eqm_warden,scores={saraka_eqm=0}] run loot replace entity @s weapon.offhand loot saraka_eqm:chests/loot_3
execute as @e[type=#saraka_eqm_warden,scores={saraka_eqm=0}] run effect give @s strength 3600 11 true

execute as @e[type=#saraka_eqm_any,scores={saraka_eqm=0}] run scoreboard players set @s saraka_eqm 1
