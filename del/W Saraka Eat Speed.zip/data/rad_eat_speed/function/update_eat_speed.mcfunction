
execute if items entity @s hotbar.0 #rad_eat_speed:rad_food unless items entity @s hotbar.0 *[custom_data~{rad_fasted:1b}] run item modify entity @s hotbar.0 rad_eat_speed:eat_speed
execute if items entity @s hotbar.1 #rad_eat_speed:rad_food unless items entity @s hotbar.1 *[custom_data~{rad_fasted:1b}] run item modify entity @s hotbar.1 rad_eat_speed:eat_speed
execute if items entity @s hotbar.2 #rad_eat_speed:rad_food unless items entity @s hotbar.2 *[custom_data~{rad_fasted:1b}] run item modify entity @s hotbar.2 rad_eat_speed:eat_speed
execute if items entity @s hotbar.3 #rad_eat_speed:rad_food unless items entity @s hotbar.3 *[custom_data~{rad_fasted:1b}] run item modify entity @s hotbar.3 rad_eat_speed:eat_speed
execute if items entity @s hotbar.4 #rad_eat_speed:rad_food unless items entity @s hotbar.4 *[custom_data~{rad_fasted:1b}] run item modify entity @s hotbar.4 rad_eat_speed:eat_speed
execute if items entity @s hotbar.5 #rad_eat_speed:rad_food unless items entity @s hotbar.5 *[custom_data~{rad_fasted:1b}] run item modify entity @s hotbar.5 rad_eat_speed:eat_speed
execute if items entity @s hotbar.6 #rad_eat_speed:rad_food unless items entity @s hotbar.6 *[custom_data~{rad_fasted:1b}] run item modify entity @s hotbar.6 rad_eat_speed:eat_speed
execute if items entity @s hotbar.7 #rad_eat_speed:rad_food unless items entity @s hotbar.7 *[custom_data~{rad_fasted:1b}] run item modify entity @s hotbar.7 rad_eat_speed:eat_speed
execute if items entity @s hotbar.8 #rad_eat_speed:rad_food unless items entity @s hotbar.8 *[custom_data~{rad_fasted:1b}] run item modify entity @s hotbar.8 rad_eat_speed:eat_speed

execute if items entity @s inventory.0 #rad_eat_speed:rad_food unless items entity @s inventory.0 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.0 rad_eat_speed:eat_speed
execute if items entity @s inventory.1 #rad_eat_speed:rad_food unless items entity @s inventory.1 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.1 rad_eat_speed:eat_speed
execute if items entity @s inventory.2 #rad_eat_speed:rad_food unless items entity @s inventory.2 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.2 rad_eat_speed:eat_speed
execute if items entity @s inventory.3 #rad_eat_speed:rad_food unless items entity @s inventory.3 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.3 rad_eat_speed:eat_speed
execute if items entity @s inventory.4 #rad_eat_speed:rad_food unless items entity @s inventory.4 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.4 rad_eat_speed:eat_speed
execute if items entity @s inventory.5 #rad_eat_speed:rad_food unless items entity @s inventory.5 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.5 rad_eat_speed:eat_speed
execute if items entity @s inventory.6 #rad_eat_speed:rad_food unless items entity @s inventory.6 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.6 rad_eat_speed:eat_speed
execute if items entity @s inventory.7 #rad_eat_speed:rad_food unless items entity @s inventory.7 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.7 rad_eat_speed:eat_speed
execute if items entity @s inventory.8 #rad_eat_speed:rad_food unless items entity @s inventory.8 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.8 rad_eat_speed:eat_speed
execute if items entity @s inventory.9 #rad_eat_speed:rad_food unless items entity @s inventory.9 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.9 rad_eat_speed:eat_speed
execute if items entity @s inventory.10 #rad_eat_speed:rad_food unless items entity @s inventory.10 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.10 rad_eat_speed:eat_speed
execute if items entity @s inventory.11 #rad_eat_speed:rad_food unless items entity @s inventory.11 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.11 rad_eat_speed:eat_speed
execute if items entity @s inventory.12 #rad_eat_speed:rad_food unless items entity @s inventory.12 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.12 rad_eat_speed:eat_speed
execute if items entity @s inventory.13 #rad_eat_speed:rad_food unless items entity @s inventory.13 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.13 rad_eat_speed:eat_speed
execute if items entity @s inventory.14 #rad_eat_speed:rad_food unless items entity @s inventory.14 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.14 rad_eat_speed:eat_speed
execute if items entity @s inventory.15 #rad_eat_speed:rad_food unless items entity @s inventory.15 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.15 rad_eat_speed:eat_speed
execute if items entity @s inventory.16 #rad_eat_speed:rad_food unless items entity @s inventory.16 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.16 rad_eat_speed:eat_speed
execute if items entity @s inventory.17 #rad_eat_speed:rad_food unless items entity @s inventory.17 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.17 rad_eat_speed:eat_speed
execute if items entity @s inventory.18 #rad_eat_speed:rad_food unless items entity @s inventory.18 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.18 rad_eat_speed:eat_speed
execute if items entity @s inventory.19 #rad_eat_speed:rad_food unless items entity @s inventory.19 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.19 rad_eat_speed:eat_speed
execute if items entity @s inventory.20 #rad_eat_speed:rad_food unless items entity @s inventory.20 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.20 rad_eat_speed:eat_speed
execute if items entity @s inventory.21 #rad_eat_speed:rad_food unless items entity @s inventory.21 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.21 rad_eat_speed:eat_speed
execute if items entity @s inventory.22 #rad_eat_speed:rad_food unless items entity @s inventory.22 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.22 rad_eat_speed:eat_speed
execute if items entity @s inventory.23 #rad_eat_speed:rad_food unless items entity @s inventory.23 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.23 rad_eat_speed:eat_speed
execute if items entity @s inventory.24 #rad_eat_speed:rad_food unless items entity @s inventory.24 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.24 rad_eat_speed:eat_speed
execute if items entity @s inventory.25 #rad_eat_speed:rad_food unless items entity @s inventory.25 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.25 rad_eat_speed:eat_speed
execute if items entity @s inventory.26 #rad_eat_speed:rad_food unless items entity @s inventory.26 *[custom_data~{rad_fasted:1b}] run item modify entity @s inventory.26 rad_eat_speed:eat_speed

execute if items entity @s weapon.offhand #rad_eat_speed:rad_food unless items entity @s weapon.offhand *[custom_data~{rad_fasted:1b}] run item modify entity @s weapon.offhand rad_eat_speed:eat_speed

advancement revoke @s only rad_eat_speed:update_eat_speed
recipe take @s rad_eat_speed:update_eat_speed
