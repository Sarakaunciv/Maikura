class_name Basic
extends EnemyBase

@onready var sprite_2d: Sprite2D = $Sprite2D
func _ready():
	sprite_2d.global_position.y += randi_range(-8, 8)

func _physics_process(delta: float):
	position.x -= move_speed * delta

func _on_area_2d_area_entered(area: Area2D):
	var turret = area.get_node("..")
	if turret.hp_left < attack_damage:
		self.global_position.x += knockback_distance * turret.hp_left / attack_damage
	else:
		self.global_position.x += knockback_distance
	turret.hp_left -= attack_damage
	var health_bar = turret.get_node("HealthBar")
	health_bar.update_health_bar()
	if turret.hp_left <= 0:
		var tile_turret = turret.get_node("..")
		tile_turret.kill_node()
	self.global_position.x += knockback_distance

func death():
	queue_free()
