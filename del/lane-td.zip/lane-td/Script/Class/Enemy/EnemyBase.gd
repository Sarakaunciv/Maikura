class_name EnemyBase
extends Node2D

var hp_max: int = 200
var hp_left: int = 200

var attack_damage: int = 50

var multiplier: float = 1
var move_speed: int = 30
var knockback_distance: int = 15
