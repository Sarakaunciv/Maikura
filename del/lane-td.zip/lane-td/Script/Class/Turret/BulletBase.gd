class_name BulletBase
extends Node2D

var bullet_speed: int = 400
var bullet_damage: int = 20
