class_name A1bullet
extends BulletBase

@onready var sprite_2d: Sprite2D = $Sprite2D
func _ready() -> void:
	var del_position_y = randf_range(-8, 8)
	sprite_2d.global_position += Vector2(0, del_position_y)

func _physics_process(delta: float):
	position.x += bullet_speed * delta

func _on_visible_on_screen_notifier_2d_screen_exited() -> void:
	queue_free()

var is_hit: bool = false
func _on_area_2d_area_entered(area: Area2D) -> void:
	if is_hit == true:
		return
	else:
		is_hit = true
		var enemy = area.get_parent()
		enemy.hp_left -= bullet_damage
		var health_bar = enemy.get_node("Sprite2D/HealthBar")
		health_bar.update_health_bar()
		if enemy.hp_left <= 0:
			enemy.death()
		queue_free()
