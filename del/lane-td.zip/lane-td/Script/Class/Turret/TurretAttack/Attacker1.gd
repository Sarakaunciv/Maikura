class_name Attacker1
extends TurretBase

@export var attack_damage: int = 20
@export var attack_delay: float = 1.5

@onready var timer_regen_hp: Timer = $TimerRegenHp
@onready var timer_attack: Timer = $TimerAttack

func _ready():
	timer_regen_hp.wait_time = hp_regen_time
	timer_regen_hp.timeout.connect(hp_regen)
	timer_regen_hp.start()
	timer_attack.wait_time = attack_delay
	timer_attack.timeout.connect(attack)
	timer_attack.start()

func hp_regen():
	hp_left = hp_left + hp_regen_hp
	if hp_left > hp_max:
		hp_left = hp_max
	var health_bar = get_node("HealthBar")
	health_bar.update_health_bar()

var load0 = load("res://Script/Class/Turret/TurretAttack/a_1_bullet.tscn")
@onready var marker_2d: Marker2D = $Marker2D

func attack():
	var bullet: A1bullet = load0.instantiate()
	add_child(bullet)
