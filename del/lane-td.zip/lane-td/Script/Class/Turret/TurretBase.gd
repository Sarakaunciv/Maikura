class_name TurretBase
extends Node2D

var hp_max: int = 300
var hp_left: int = 300
var hp_regen_hp: int = 30
var hp_regen_time: float = 10.0

var tile_occu: Vector2
