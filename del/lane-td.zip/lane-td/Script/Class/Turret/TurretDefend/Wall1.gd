class_name TurretDefend
extends TurretBase

@onready var timer_regen_hp: Timer = $TimerRegenHp

func _ready():
	hp_max = 4000
	hp_left = 4000
	hp_regen_hp = 400
	timer_regen_hp.wait_time = hp_regen_time
	timer_regen_hp.timeout.connect(hp_regen)
	timer_regen_hp.start()

func hp_regen():
	hp_left = hp_left + hp_regen_hp
	if hp_left > hp_max:
		hp_left = hp_max
	var health_bar = get_node("HealthBar")
	health_bar.update_health_bar()
