class_name Energizer1
extends TurretBase

@export var energy_value: int = 10
@export var time_generation: float = 16.0
@export var time_generation_first: float = 3.0
@export var total_energizer_max: int = 5

@onready var timer_regen_hp: Timer = $TimerRegenHp
@onready var timer_generation: Timer = $TimerGeneration
@onready var timer_generation_first: Timer = $TimerGenerationFirst

func _ready():
	timer_regen_hp.wait_time = hp_regen_time
	timer_regen_hp.timeout.connect(hp_regen)
	timer_regen_hp.start()
	timer_generation.wait_time = time_generation
	timer_generation.timeout.connect(generate_energy)
	timer_generation.start()
	if Global.total_energizer >= total_energizer_max:
		timer_generation_first.wait_time = time_generation_first + total_energizer_max
	elif  Global.total_energizer > 0:
		timer_generation_first.wait_time = time_generation_first + Global.total_energizer
	elif Global.total_energizer == 0:
		timer_generation_first.wait_time = time_generation_first
	timer_generation_first.timeout.connect(generate_energy)
	timer_generation_first.start()
	Global.total_energizer += 1

func hp_regen():
	hp_left = hp_left + hp_regen_hp
	if hp_left > hp_max:
		hp_left = hp_max
	var health_bar = get_node("HealthBar")
	health_bar.update_health_bar()

var load0 = load("res://Script/Class/Turret/TurretGeneration/energy.tscn")

func generate_energy():
	var energy: Energy = load0.instantiate()
	add_child(energy)
 
