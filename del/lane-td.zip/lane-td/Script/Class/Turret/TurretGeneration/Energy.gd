class_name Energy
extends Node2D

var energy_value_in_unit: int = 0

func _ready() -> void:
	var parent = get_node("..")
	energy_value_in_unit = parent.energy_value
	var del_position_x = randf_range(-30, 30)
	var del_position_y = randf_range(-30, 30)
	self.global_position += Vector2(del_position_x, del_position_y)

func _on_color_rect_mouse_entered() -> void:
	Global.add_energy(energy_value_in_unit)
	queue_free()
