extends Node2D

var type: int = 0
var level: int = 0

var occupy: int = 0

@onready var turret_tile: Node2D = $"."

func kill_node():
	var kill_child = get_node("Turret")
	kill_child.queue_free()
	occupy = 0
	type = 0
	level = 0

func _on_button_mouse_entered() -> void:
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		_on_button_pressed()

func _on_button_pressed() -> void:
	if LevelManager.hold_item_id == 101 and occupy == 1:
		kill_node()
	if Global.energy >= 0 and occupy == 0:
		match LevelManager.hold_item_id:
			1:
				plant_energizer1()
			2:
				plant_attacker1()
			3:
				plant_wall1()

var energizer1 = load("res://Script/Class/Turret/TurretGeneration/energizer1.tscn")
var attacker1 = load("res://Script/Class/Turret/TurretAttack/attacker1.tscn")
var wall1 = load("res://Script/Class/Turret/TurretDefend/wall1.tscn")
func plant_energizer1():
	var energizer1_node = energizer1.instantiate()
	turret_tile.add_child(energizer1_node)
	energizer1_node.global_position = self.global_position
	type = 1
	level = 1
	occupy = 1
	Global.add_energy(Global.Energizer1_Cost)
func plant_attacker1():
	var attacker1_node = attacker1.instantiate()
	turret_tile.add_child(attacker1_node)
	attacker1_node.global_position = self.global_position
	type = 2
	level = 1
	occupy = 1
	Global.add_energy(Global.Attacker1_Cost)
func plant_wall1():
	var wall1_node = wall1.instantiate()
	turret_tile.add_child(wall1_node)
	wall1_node.global_position = self.global_position
	type = 3
	level = 1
	occupy = 1
	Global.add_energy(Global.Wall1_Cost)

@onready var button: Button = $Button
func _input(event):
	if event is InputEventKey and event.pressed:
		if event.keycode == KEY_Z:
			if button.visible == true:
				button.visible = false
			else:
				button.visible = true
