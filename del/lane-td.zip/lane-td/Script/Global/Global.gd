extends Node

signal set_energy(set_ting)

var energy: int = 0
var total_energy_value: int = 0
var total_energizer: int = 0

func add_energy(energy_value):
	energy += energy_value
	set_energy.emit(energy)

#Energy Cost
var Energizer1_Cost: int = -10
var Attacker1_Cost: int = -50
var Wall1_Cost: int = -100

#Enemy
var basic_0_p = 3
var fast_0_p = 8
