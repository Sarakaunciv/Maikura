class_name LevelCommon
extends Node2D

@onready var _0_cursor: Node2D = $"0Cursor"
@onready var enemy_timer: Timer = $EnemyTimer
@onready var enemy_timer_first: Timer = $EnemyTimerFirst
var wave_value_current: int = 0
func _ready():
	LevelManager.cursor_turret = _0_cursor
	create_grid()
	setup_level()
	enemy_timer_first.wait_time = LevelManager.wave_timer_first
	enemy_timer_first.timeout.connect(start_first_wave)
	enemy_timer_first.start()
	enemy_timer.wait_time = LevelManager.wave_timer
	enemy_timer.timeout.connect(spawn_wave)
func start_first_wave():
	spawn_wave()
	enemy_timer.start()

func setup_level():
	match LevelManager.level_world:
		0:
			LevelManager.level_wave = 1000
			LevelManager.wave_value = 1
			wave_value_current = LevelManager.wave_value
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_add_add = 1
			LevelManager.wave_value_add_goal = 3
			LevelManager.wave_value_goal = 4
			LevelManager.wave_timer = 8
			LevelManager.wave_timer_first = 12
		1:
			LevelManager.level_wave = 40
			LevelManager.wave_value = 1
			wave_value_current = LevelManager.wave_value
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_add_add = 1
			LevelManager.wave_value_add_goal = 2
			LevelManager.wave_value_goal = 3
			LevelManager.wave_timer = 8
			LevelManager.wave_timer_first = 12
		2:
			LevelManager.level_wave = 60
			LevelManager.wave_value = 2
			wave_value_current = LevelManager.wave_value
			LevelManager.wave_value_add = 1
			LevelManager.wave_value_add_add = 1
			LevelManager.wave_value_add_goal = 2
			LevelManager.wave_value_goal = 2
			LevelManager.wave_timer = 8
			LevelManager.wave_timer_first = 12

@onready var grid: Node2D = $Grid
func create_grid():
	var tile = load("res://Script/ECT/turret_tile.tscn")
	for x in range(20):
		for y in range(8):
			var tile_node = tile.instantiate()
			grid.add_child(tile_node)
			tile_node.position = Vector2(x, y) * Vector2(80, 80)

var lane: int
var enemy_value: int

var basic_0 = load("res://Script/Class/Enemy/Basic/basic_0.tscn")
var fast0 = load("res://Script/Class/Enemy/Basic/fast_0.tscn")
func spawn_basic_0():
	enemy_value = 1
	var enemy = basic_0.instantiate()
	enemy_spawner.add_child(enemy)
	enemy.global_position = enemy_spawner.global_position + Vector2(0, 80 * lane)
func spawn_fast_0():
	enemy_value = 2
	var enemy = fast0.instantiate()
	enemy_spawner.add_child(enemy)
	enemy.global_position = enemy_spawner.global_position + Vector2(0, 80 * lane)

var enemy_point_current
var enemy_point_max: int = 0
func spawn_enemy():
	if wave_value_current >= 2:
		enemy_point_max = Global.fast_0_p
	else:
		enemy_point_max = Global.basic_0_p
	enemy_point_current = randi_range(0, enemy_point_max)
	#Select Enemy
	if enemy_point_current > Global.basic_0_p and LevelManager.fast_0_eneble == true:
		spawn_fast_0()
	else:
		spawn_basic_0()

@onready var enemy_spawner: Node2D = $EnemySpawner
func spawn_wave():
	if LevelManager.level_wave == 0:
		return
	if wave_value_current == 0:
		pass
	else:
		select_lane()
		spawn_wave()
		return
	LevelManager.level_wave -= 1
	LevelManager.wave_value_goal_current += 1
	if LevelManager.wave_value_goal_current == LevelManager.wave_value_goal:
		LevelManager.wave_value_goal_current = 0
		LevelManager.wave_value += LevelManager.wave_value_add
		LevelManager.wave_value_add_goal_current += 1
		if LevelManager.wave_value_add_goal_current == LevelManager.wave_value_add_goal:
			LevelManager.wave_value_add += LevelManager.wave_value_add_add
	wave_value_current = LevelManager.wave_value

func select_lane():
	var lane_value = min(LevelManager.lane_0, LevelManager.lane_1, LevelManager.lane_2, LevelManager.lane_3, LevelManager.lane_4, LevelManager.lane_5, LevelManager.lane_6, LevelManager.lane_7)
	match lane_value:
		LevelManager.lane_0:
			lane = 0
			spawn_enemy()	
			wave_value_current -= enemy_value
			LevelManager.lane_0 += enemy_value
		LevelManager.lane_1:
			lane = 1
			spawn_enemy()	
			wave_value_current -= enemy_value
			LevelManager.lane_1 += enemy_value
		LevelManager.lane_2:
			lane = 2
			spawn_enemy()	
			wave_value_current -= enemy_value
			LevelManager.lane_2 += enemy_value
		LevelManager.lane_3:
			lane = 3
			spawn_enemy()	
			wave_value_current -= enemy_value
			LevelManager.lane_3 += enemy_value
		LevelManager.lane_4:
			lane = 4
			spawn_enemy()	
			wave_value_current -= enemy_value
			LevelManager.lane_4 += enemy_value
		LevelManager.lane_5:
			lane = 5
			spawn_enemy()	
			wave_value_current -= enemy_value
			LevelManager.lane_5 += enemy_value
		LevelManager.lane_6:
			lane = 6
			spawn_enemy()	
			wave_value_current -= enemy_value
			LevelManager.lane_6 += enemy_value
		LevelManager.lane_7:
			lane = 7
			spawn_enemy()	
			wave_value_current -= enemy_value
			LevelManager.lane_7 += enemy_value
