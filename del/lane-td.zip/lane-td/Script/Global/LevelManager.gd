extends Node2D

var hold_item_id: int = 0
var cursor_turret: Node2D
func _physics_process(delta: float) -> void:
	if cursor_turret != null:
		cursor_turret.global_position = get_global_mouse_position()

var level_world: int = 1
var level_max: int = 2
var level_wave: int = 0
var wave_value: int = 0
var wave_value_add: int = 0
var wave_value_add_add: int = 0
var wave_value_add_goal: int = 0
var wave_value_add_goal_current: int = 0
var wave_value_goal: int = 0
var wave_value_goal_current: int = 0
var wave_timer_first: int = 0
var wave_timer: int = 0

var fast_0_eneble: bool = true

var lane_0: int = 0
var lane_1: int = 0
var lane_2: int = 0
var lane_3: int = 0
var lane_4: int = 0
var lane_5: int = 0
var lane_6: int = 0
var lane_7: int = 0
