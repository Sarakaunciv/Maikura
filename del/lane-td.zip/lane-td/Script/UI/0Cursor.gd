class_name Cursor
extends Node2D

@onready var sprite_2d: Sprite2D = $Sprite2D

func _ready() -> void:
	holding_content()

func _process(delta: float) -> void:
	holding_content()

func _input(event):
	if event is InputEventKey and event.pressed:
		if event.keycode == KEY_A:
			LevelManager.hold_item_id = 0

func holding_content():
	match LevelManager.hold_item_id:
		0:
			sprite_2d.visible = false
		1:
			sprite_2d.region_rect.position.x = 64
			sprite_2d.region_rect.position.y = 0
			sprite_2d.visible = true
		2:
			sprite_2d.region_rect.position.x = 64
			sprite_2d.region_rect.position.y = 8
			sprite_2d.visible = true
		3:
			sprite_2d.region_rect.position.x = 64
			sprite_2d.region_rect.position.y = 24
			sprite_2d.visible = true
		101:
			sprite_2d.region_rect.position.x = 32
			sprite_2d.region_rect.position.y = 8
			sprite_2d.visible = true
	pass
