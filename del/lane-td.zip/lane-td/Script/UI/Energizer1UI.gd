extends Node2D

func _on_button_pressed() -> void:
	LevelManager.hold_item_id = 1

func _input(event):
	if event is InputEventKey and event.pressed:
		if event.keycode == KEY_1:
			_on_button_pressed()

@onready var edge_hover: Sprite2D = $EdgeHover

func _on_button_mouse_entered() -> void:
	edge_hover.visible = true

func _on_button_mouse_exited() -> void:
	edge_hover.visible = false
