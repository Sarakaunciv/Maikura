extends Node2D

@onready var energy_label: Label = $Energy/Label

func _ready():
	Global.set_energy.connect(update_energy_label)

func update_energy_label(energy: int):
	energy_label.text = str(energy)
