package net.saraka.rad_mod.item;

import net.minecraft.Util;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.LazyLoadedValue;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ArmorMaterials;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.ItemLike;

import java.util.EnumMap;
import java.util.function.Supplier;

public enum ModArmorMaterials implements ArmorMaterial
{
    RAD("rad", 90, (EnumMap)Util.make(new EnumMap(ArmorItem.Type.class), (p_266655_) -> {
    p_266655_.put(ArmorItem.Type.BOOTS, 9);
    p_266655_.put(ArmorItem.Type.LEGGINGS, 18);
    p_266655_.put(ArmorItem.Type.CHESTPLATE, 24);
    p_266655_.put(ArmorItem.Type.HELMET, 9);
    }), 50, SoundEvents.ARMOR_EQUIP_NETHERITE, 5.0F, 0.25F, () -> Ingredient.of(new ItemLike[]{
            Items.NETHERITE_BLOCK})),
    STONE("stone", 10, (EnumMap)Util.make(new EnumMap(ArmorItem.Type.class), (p_266655_) -> {
        p_266655_.put(ArmorItem.Type.BOOTS, 2);
        p_266655_.put(ArmorItem.Type.LEGGINGS, 4);
        p_266655_.put(ArmorItem.Type.CHESTPLATE, 6);
        p_266655_.put(ArmorItem.Type.HELMET, 2);
    }), 50, SoundEvents.ARMOR_EQUIP_CHAIN, 0f, 0.1F, () -> Ingredient.of(new ItemLike[]{
            Items.COBBLESTONE})),
    BRIGHT_IRON("bright_iron", 20, (EnumMap)Util.make(new EnumMap(ArmorItem.Type.class), (p_266655_) -> {
    p_266655_.put(ArmorItem.Type.BOOTS, 3);
    p_266655_.put(ArmorItem.Type.LEGGINGS, 6);
    p_266655_.put(ArmorItem.Type.CHESTPLATE, 8);
    p_266655_.put(ArmorItem.Type.HELMET, 3);
    }), 50, SoundEvents.ARMOR_EQUIP_IRON, 0f, 0.1F, () -> Ingredient.of(new ItemLike[]{
            Items.IRON_INGOT})),
    BRIGHT_DIAMOND("bright_diamond", 30, (EnumMap)Util.make(new EnumMap(ArmorItem.Type.class), (p_266655_) -> {
        p_266655_.put(ArmorItem.Type.BOOTS, 4);
        p_266655_.put(ArmorItem.Type.LEGGINGS, 9);
        p_266655_.put(ArmorItem.Type.CHESTPLATE, 12);
        p_266655_.put(ArmorItem.Type.HELMET, 5);
    }), 50, SoundEvents.ARMOR_EQUIP_DIAMOND, 2.0f, 0.15F, () -> Ingredient.of(new ItemLike[]{
            Items.DIAMOND})),
    RED_NETHERITE("red_netherite", 45, (EnumMap)Util.make(new EnumMap(ArmorItem.Type.class), (p_266655_) -> {
        p_266655_.put(ArmorItem.Type.BOOTS, 6);
        p_266655_.put(ArmorItem.Type.LEGGINGS, 12);
        p_266655_.put(ArmorItem.Type.CHESTPLATE, 16);
        p_266655_.put(ArmorItem.Type.HELMET, 6);
    }), 50, SoundEvents.ARMOR_EQUIP_NETHERITE, 3.0f, 0.2F, () -> Ingredient.of(new ItemLike[]{
            Items.NETHERITE_INGOT}));

    public static final StringRepresentable.EnumCodec<ArmorMaterials> CODEC = StringRepresentable.fromEnum(ArmorMaterials::values);
    private static final EnumMap<ArmorItem.Type, Integer> HEALTH_FUNCTION_FOR_TYPE = (EnumMap) Util.make(new EnumMap(ArmorItem.Type.class), (p_266653_) -> {
        p_266653_.put(ArmorItem.Type.BOOTS, 180);
        p_266653_.put(ArmorItem.Type.LEGGINGS, 180);
        p_266653_.put(ArmorItem.Type.CHESTPLATE, 180);
        p_266653_.put(ArmorItem.Type.HELMET, 180);
    });
    private final String name;
    private final int durabilityMultiplier;
    private final EnumMap<ArmorItem.Type, Integer> protectionFunctionForType;
    private final int enchantmentValue;
    private final SoundEvent sound;
    private final float toughness;
    private final float knockbackResistance;
    private final LazyLoadedValue<Ingredient> repairIngredient;

    private ModArmorMaterials(String p_268171_, int p_268303_, EnumMap<ArmorItem.Type, Integer> p_267941_, int p_268086_, SoundEvent p_268145_, float p_268058_, float p_268180_, Supplier<Ingredient> p_268256_) {
        this.name = p_268171_;
        this.durabilityMultiplier = p_268303_;
        this.protectionFunctionForType = p_267941_;
        this.enchantmentValue = p_268086_;
        this.sound = p_268145_;
        this.toughness = p_268058_;
        this.knockbackResistance = p_268180_;
        this.repairIngredient = new LazyLoadedValue(p_268256_);
    }

    public int getDurabilityForType(ArmorItem.Type p_266745_) {
        return (Integer)HEALTH_FUNCTION_FOR_TYPE.get(p_266745_) * this.durabilityMultiplier;
    }

    public int getDefenseForType(ArmorItem.Type p_266752_) {
        return (Integer)this.protectionFunctionForType.get(p_266752_);
    }

    public int getEnchantmentValue() {
        return this.enchantmentValue;
    }

    public SoundEvent getEquipSound() {
        return this.sound;
    }

    public Ingredient getRepairIngredient() {
        return (Ingredient)this.repairIngredient.get();
    }

    public String getName() {
        return this.name;
    }

    public float getToughness() {
        return this.toughness;
    }

    public float getKnockbackResistance() {
        return this.knockbackResistance;
    }

    public String getSerializedName() {
        return this.name;
    }
}
