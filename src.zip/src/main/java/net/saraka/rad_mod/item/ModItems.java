package net.saraka.rad_mod.item;

import net.minecraft.world.item.*;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.saraka.rad_mod.RadMod;
import net.saraka.rad_mod.item.custom.FuelItem;
import net.saraka.rad_mod.item.custom.ModFoodProperties;
import net.saraka.rad_mod.item.custom.RadArmorItem;

public class ModItems
{
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, RadMod.MOD_ID);

    public static final RegistryObject<Item> RAD = ITEMS.register("rad",
            () -> new Item(new Item.Properties().food(ModFoodProperties.RAD).fireResistant()));

    public static final RegistryObject<Item> RAD_SWORD = ITEMS.register("rad_sword",
            () -> new SwordItem(ModToolTiers.RAD, 185, 0f, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> RAD_PICKAXE = ITEMS.register("rad_pickaxe",
            () -> new PickaxeItem(ModToolTiers.RAD, 65, 2f, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> RAD_AXE = ITEMS.register("rad_axe",
            () -> new AxeItem(ModToolTiers.RAD, 385, -2.4f, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> RAD_SHOVEL = ITEMS.register("rad_shovel",
            () -> new ShovelItem(ModToolTiers.RAD, 45, 4f, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> RAD_HOE = ITEMS.register("rad_hoe",
            () -> new HoeItem(ModToolTiers.RAD, 25, 12f, new Item.Properties().fireResistant()));

    public static final RegistryObject<Item> RAD_SWORD_LOOT = ITEMS.register("rad_sword_loot",
            () -> new SwordItem(ModToolTiers.RAD, 185, 4f, new Item.Properties().fireResistant()));

    public static final RegistryObject<Item> RAD_HELMET = ITEMS.register("rad_helmet",
            () -> new RadArmorItem(ModArmorMaterials.RAD, ArmorItem.Type.HELMET, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> RAD_CHESTPLATE = ITEMS.register("rad_chestplate",
            () -> new RadArmorItem(ModArmorMaterials.RAD, ArmorItem.Type.CHESTPLATE, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> RAD_LEGGINGS = ITEMS.register("rad_leggings",
            () -> new RadArmorItem(ModArmorMaterials.RAD, ArmorItem.Type.LEGGINGS, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> RAD_BOOTS = ITEMS.register("rad_boots",
            () -> new RadArmorItem(ModArmorMaterials.RAD, ArmorItem.Type.BOOTS, new Item.Properties().fireResistant()));

    public static final RegistryObject<Item> FEED_POWDER = ITEMS.register("feed_powder", () -> new Item(new Item.Properties().food(ModFoodProperties.FEED_POWDER)));
    public static final RegistryObject<Item> FEED_INGOT = ITEMS.register("feed_ingot", () -> new Item(new Item.Properties().food(ModFoodProperties.FEED_INGOT)));
    public static final RegistryObject<Item> PURE_FOOD = ITEMS.register("pure_food", () -> new Item(new Item.Properties().food(ModFoodProperties.PURE_FOOD)));

    public static final RegistryObject<Item> ROTTEN_MEAT_BALL = ITEMS.register("rotten_meat_ball", () -> new Item(new Item.Properties().food(ModFoodProperties.ROTTEN_MEAT_BALL)));
    public static final RegistryObject<Item> LEVITATE_CHORUS = ITEMS.register("levitate_chorus", () -> new Item(new Item.Properties().food(ModFoodProperties.LEVITATE_CHORUS)));
    public static final RegistryObject<Item> NETHERITE_STAR = ITEMS.register("netherite_star", () -> new Item(new Item.Properties().food(ModFoodProperties.NETHERITE_STAR)));
    public static final RegistryObject<Item> DISCOUNT_OF_THE_VILLAGE = ITEMS.register("discount_of_the_village", () -> new Item(new Item.Properties().food(ModFoodProperties.DISCOUNT_OF_THE_VILLAGE)));
    public static final RegistryObject<Item> COMPRESSED_PEARL = ITEMS.register("compressed_pearl", () -> new Item(new Item.Properties().food(ModFoodProperties.COMPRESSED_PEARL)));

    public static final RegistryObject<Item> CHARGED_COAL = ITEMS.register("charged_coal", () -> new FuelItem(new Item.Properties().food(ModFoodProperties.CHARGED_COAL), 3200));

    public static final RegistryObject<Item> FUSE_COAL = ITEMS.register("fuse_coal", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> FUSE_COPPER = ITEMS.register("fuse_copper", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> FUSE_COPPER_RAW = ITEMS.register("fuse_copper_raw", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> FUSE_DIAMOND = ITEMS.register("fuse_diamond", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> FUSE_EMERALD = ITEMS.register("fuse_emerald", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> FUSE_GOLD = ITEMS.register("fuse_gold", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> FUSE_GOLD_RAW = ITEMS.register("fuse_gold_raw", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> FUSE_IRON = ITEMS.register("fuse_iron", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> FUSE_IRON_RAW = ITEMS.register("fuse_iron_raw", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> FUSE_LAPIS = ITEMS.register("fuse_lapis", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> FUSE_NETHERITE = ITEMS.register("fuse_netherite", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> FUSE_REDSTONE = ITEMS.register("fuse_redstone", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> NETHERITE_PLATE = ITEMS.register("netherite_plate", () -> new Item(new Item.Properties()));

    public static final RegistryObject<Item> STONE_HELMET = ITEMS.register("stone_helmet", () -> new RadArmorItem(ModArmorMaterials.STONE, ArmorItem.Type.HELMET, new Item.Properties()));
    public static final RegistryObject<Item> STONE_CHESTPLATE = ITEMS.register("stone_chestplate", () -> new RadArmorItem(ModArmorMaterials.STONE, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> STONE_LEGGINGS = ITEMS.register("stone_leggings", () -> new RadArmorItem(ModArmorMaterials.STONE, ArmorItem.Type.LEGGINGS, new Item.Properties()));
    public static final RegistryObject<Item> STONE_BOOTS = ITEMS.register("stone_boots", () -> new RadArmorItem(ModArmorMaterials.STONE, ArmorItem.Type.BOOTS, new Item.Properties()));
    public static final RegistryObject<Item> BRIGHT_IRON_HELMET = ITEMS.register("bright_iron_helmet", () -> new RadArmorItem(ModArmorMaterials.BRIGHT_IRON, ArmorItem.Type.HELMET, new Item.Properties()));
    public static final RegistryObject<Item> BRIGHT_IRON_CHESTPLATE = ITEMS.register("bright_iron_chestplate", () -> new RadArmorItem(ModArmorMaterials.BRIGHT_IRON, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> BRIGHT_IRON_LEGGINGS = ITEMS.register("bright_iron_leggings", () -> new RadArmorItem(ModArmorMaterials.BRIGHT_IRON, ArmorItem.Type.LEGGINGS, new Item.Properties()));
    public static final RegistryObject<Item> BRIGHT_IRON_BOOTS = ITEMS.register("bright_iron_boots", () -> new RadArmorItem(ModArmorMaterials.BRIGHT_IRON, ArmorItem.Type.BOOTS, new Item.Properties()));
    public static final RegistryObject<Item> BRIGHT_DIAMOND_HELMET = ITEMS.register("bright_diamond_helmet", () -> new RadArmorItem(ModArmorMaterials.BRIGHT_DIAMOND, ArmorItem.Type.HELMET, new Item.Properties()));
    public static final RegistryObject<Item> BRIGHT_DIAMOND_CHESTPLATE = ITEMS.register("bright_diamond_chestplate", () -> new RadArmorItem(ModArmorMaterials.BRIGHT_DIAMOND, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> BRIGHT_DIAMOND_LEGGINGS = ITEMS.register("bright_diamond_leggings", () -> new RadArmorItem(ModArmorMaterials.BRIGHT_DIAMOND, ArmorItem.Type.LEGGINGS, new Item.Properties()));
    public static final RegistryObject<Item> BRIGHT_DIAMOND_BOOTS = ITEMS.register("bright_diamond_boots", () -> new RadArmorItem(ModArmorMaterials.BRIGHT_DIAMOND, ArmorItem.Type.BOOTS, new Item.Properties()));
    public static final RegistryObject<Item> RED_NETHERITE_HELMET = ITEMS.register("red_netherite_helmet", () -> new RadArmorItem(ModArmorMaterials.RED_NETHERITE, ArmorItem.Type.HELMET, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> RED_NETHERITE_CHESTPLATE = ITEMS.register("red_netherite_chestplate", () -> new RadArmorItem(ModArmorMaterials.RED_NETHERITE, ArmorItem.Type.CHESTPLATE, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> RED_NETHERITE_LEGGINGS = ITEMS.register("red_netherite_leggings", () -> new RadArmorItem(ModArmorMaterials.RED_NETHERITE, ArmorItem.Type.LEGGINGS, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> RED_NETHERITE_BOOTS = ITEMS.register("red_netherite_boots", () -> new RadArmorItem(ModArmorMaterials.RED_NETHERITE, ArmorItem.Type.BOOTS, new Item.Properties().fireResistant()));

    public static final RegistryObject<Item> BURNT_STONE_PICKAXE = ITEMS.register("burnt_stone_pickaxe", () -> new PickaxeItem(Tiers.NETHERITE, 5, -2.8f, new Item.Properties()));
    public static final RegistryObject<Item> BURNT_STONE_SWORD = ITEMS.register("burnt_stone_sword", () -> new SwordItem(Tiers.NETHERITE, 5, -2.4f, new Item.Properties()));
    public static final RegistryObject<Item> BURNT_STONE_AXE = ITEMS.register("burnt_stone_axe", () -> new AxeItem(Tiers.NETHERITE, 15, -3.1f, new Item.Properties()));
    public static final RegistryObject<Item> BRIGHT_IRON_SWORD = ITEMS.register("bright_iron_sword", () -> new SwordItem(Tiers.NETHERITE, 10, -2.4f, new Item.Properties()));
    public static final RegistryObject<Item> BRIGHT_IRON_AXE = ITEMS.register("bright_iron_axe", () -> new AxeItem(Tiers.NETHERITE, 25, -3f, new Item.Properties()));
    public static final RegistryObject<Item> BRIGHT_DIAMOND_SWORD = ITEMS.register("bright_diamond_sword", () -> new SwordItem(Tiers.NETHERITE, 15, -2.2f, new Item.Properties()));
    public static final RegistryObject<Item> BRIGHT_DIAMOND_AXE = ITEMS.register("bright_diamond_axe", () -> new AxeItem(Tiers.NETHERITE, 35, -2.8f, new Item.Properties()));
    public static final RegistryObject<Item> RED_NETHERITE_SWORD = ITEMS.register("red_netherite_sword", () -> new SwordItem(Tiers.NETHERITE, 35, -2f, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> RED_NETHERITE_AXE = ITEMS.register("red_netherite_axe", () -> new AxeItem(Tiers.NETHERITE, 75, -2.6f, new Item.Properties().fireResistant()));

    public static void register(IEventBus eventBus)
    {
        ITEMS.register(eventBus);
    }
}
