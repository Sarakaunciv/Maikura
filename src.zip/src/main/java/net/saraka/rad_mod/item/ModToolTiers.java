package net.saraka.rad_mod.item;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraftforge.common.ForgeTier;
import net.minecraftforge.common.TierSortingRegistry;
import net.saraka.rad_mod.RadMod;

import java.util.List;

public class ModToolTiers
{
    public static Tier RAD;

    static
    {
        RAD = TierSortingRegistry.registerTier(
                new ForgeTier(5,8100, 275f, 14f, 1,
                        null, () -> Ingredient.of(ModItems.RAD.get())),
                null, List.of(Tiers.NETHERITE), List.of()
        );
    }
}
