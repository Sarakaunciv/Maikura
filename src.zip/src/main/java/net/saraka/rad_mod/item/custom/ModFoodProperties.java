package net.saraka.rad_mod.item.custom;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;

public class ModFoodProperties
{
    public static final FoodProperties RAD = new FoodProperties.Builder().nutrition(80).saturationMod(1f).fast().alwaysEat()
            .effect(new MobEffectInstance(MobEffects.ABSORPTION, 24000, 19), 1.0F)
            .effect(new MobEffectInstance(MobEffects.REGENERATION, 400, 9), 1.0F).build();

    public static final FoodProperties FEED_POWDER = new FoodProperties.Builder().nutrition(2).saturationMod(1f).fast().alwaysEat().build();
    public static final FoodProperties FEED_INGOT = new FoodProperties.Builder().nutrition(20).saturationMod(1f).fast().alwaysEat().build();
    public static final FoodProperties PURE_FOOD = new FoodProperties.Builder().nutrition(40).saturationMod(0f).fast().alwaysEat()
            .effect(new MobEffectInstance(MobEffects.ABSORPTION, 12000, 3), 1.0F)
            .effect(new MobEffectInstance(MobEffects.REGENERATION, 40, 9), 1.0F).build();

    public static final FoodProperties ROTTEN_MEAT_BALL = new FoodProperties.Builder().nutrition(16).saturationMod(0.1f).fast().alwaysEat()
            .effect(new MobEffectInstance(MobEffects.HUNGER, 600, 0), 1.0F).build();

    public static final FoodProperties CHARGED_COAL = new FoodProperties.Builder().nutrition(6).saturationMod(0.6f).fast().alwaysEat()
            .effect(new MobEffectInstance(MobEffects.DIG_SPEED, 12000, 19), 1.0F).build();

    public static final FoodProperties NETHERITE_STAR = new FoodProperties.Builder().nutrition(16).saturationMod(2f).fast().alwaysEat()
            .effect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 144000, 3), 1.0F).build();

    public static final FoodProperties DISCOUNT_OF_THE_VILLAGE = new FoodProperties.Builder().nutrition(6).saturationMod(1f).fast().alwaysEat()
            .effect(new MobEffectInstance(MobEffects.HERO_OF_THE_VILLAGE, 144000, 19), 1.0F).build();

    public static final FoodProperties LEVITATE_CHORUS = new FoodProperties.Builder().nutrition(4).saturationMod(1.2f).fast().alwaysEat().build();

    public static final FoodProperties COMPRESSED_PEARL = new FoodProperties.Builder().nutrition(20).saturationMod(2f).fast().alwaysEat().build();
}