package net.saraka.rad_mod.item.custom;

import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;

public class RadArmorItem extends ArmorItem {
    public RadArmorItem(ArmorMaterial material, Type type, Properties properties) {
        super(material, type, properties);
    }
}
