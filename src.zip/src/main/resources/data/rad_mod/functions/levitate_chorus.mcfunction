effect clear @s levitation

advancement revoke @s only rad_mod:levitate_chorus