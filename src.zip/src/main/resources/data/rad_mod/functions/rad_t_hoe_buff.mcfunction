clear @s knowledge_book 1

give @s rad_mod:rad_hoe{Enchantments:[{lvl:39,id:sharpness},{lvl:5,id:efficiency},{lvl:3,id:unbreaking},{lvl:1,id:mending}]}

advancement revoke @s only rad_mod:rad_t_hoe_buff
recipe take @s rad_mod:rad_t_hoe_buff