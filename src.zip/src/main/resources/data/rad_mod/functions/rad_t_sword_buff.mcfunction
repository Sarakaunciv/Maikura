clear @s knowledge_book 1

give @s rad_mod:rad_sword_loot{Enchantments:[{lvl:15,id:looting},{lvl:255,id:sweeping},{lvl:3,id:unbreaking},{lvl:1,id:mending}]}
give @s rad_mod:rad_sword{Enchantments:[{lvl:199,id:sharpness},{lvl:255,id:sweeping},{lvl:3,id:unbreaking},{lvl:1,id:mending}]}

advancement revoke @s only rad_mod:rad_t_sword_buff
recipe take @s rad_mod:rad_t_sword_buff